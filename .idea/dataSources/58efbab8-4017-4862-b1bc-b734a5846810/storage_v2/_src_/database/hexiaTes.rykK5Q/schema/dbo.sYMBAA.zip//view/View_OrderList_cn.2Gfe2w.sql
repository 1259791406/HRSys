CREATE VIEW [dbo].[View_OrderList_cn] AS SELECT id AS ID,vin AS 车架号,CASE WHEN O_type = 1 THEN '融租' WHEN O_type = 2 THEN '经租' ELSE '未知' END AS 订单类型,contractNumber AS 合同编号,contractNumberPrice AS 合同金额,a_code AS 调拨单Code,Ca_code AS 测算单Code,CASE C_Name WHEN '' THEN C_Name ELSE (SELECT name FROM Customer WHERE id = C_Name) END AS 客户名称,Oid AS 订单号,Flowing AS 流水号,CONVERT(VARCHAR(100), time, 20) AS 订单时间,FirstPrice AS 首付款,LastPrice AS 尾款,MothNum AS 期数,MothPrice AS 月供,CarPrice AS 车辆价格,ServicePrice AS 服务收入,CASE WHEN istrue = 1 THEN '打开' WHEN istrue = 2 THEN '关闭' ELSE '未知' END AS 订单是否关闭 FROM OrderList
go

