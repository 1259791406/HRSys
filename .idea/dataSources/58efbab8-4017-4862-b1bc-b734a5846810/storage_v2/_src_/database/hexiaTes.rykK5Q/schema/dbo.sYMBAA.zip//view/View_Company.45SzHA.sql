CREATE VIEW [dbo].[View_Company] AS SELECT code AS id,paratcode,name AS title,u8code AS code FROM Company
go

