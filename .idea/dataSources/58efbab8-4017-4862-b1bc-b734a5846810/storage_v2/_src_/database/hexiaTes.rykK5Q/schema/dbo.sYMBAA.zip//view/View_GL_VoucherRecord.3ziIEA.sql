CREATE VIEW [dbo].[View_GL_VoucherRecord] AS SELECT id,marke,inum,code,YearMouthDay, CONVERT(DECIMAL(18,2), JieCountPrice) AS JieCountPrice,CONVERT(DECIMAL(18,2), DaiCountPrice) AS DaiCountPrice,CONVERT(VARCHAR(100),SysTime, 20) AS SysTime,Remarks,state,CONVERT(VARCHAR(100),time, 20) AS time FROM GL_VoucherRecord
go

