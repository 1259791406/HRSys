CREATE VIEW [dbo].[View_Mouth_Calculation] AS SELECT id,code,id AS inum,orderid,CASE username WHEN '' THEN username ELSE (SELECT name FROM Customer WHERE id = username) END AS username,vin,principal,cost,m_supply AS MothPrice, rate, profit,CONVERT(VARCHAR(100), m_time, 23) AS time FROM Calculation  WHERE istrue = 1 AND DATEDIFF(mm,m_time,GETDATE()) = 0
go

