CREATE VIEW [dbo].[View_Calculation] AS SELECT id,code,inum,orderid,CASE username WHEN '' THEN username ELSE (SELECT name FROM Customer WHERE id = username) END AS username,vin,principal,cost,m_supply AS MothPrice, rate, profit,CONVERT(VARCHAR(100), m_time, 23) AS time,CONVERT(VARCHAR(100), time, 20) AS addTime,istrue,state FROM Calculation
go

