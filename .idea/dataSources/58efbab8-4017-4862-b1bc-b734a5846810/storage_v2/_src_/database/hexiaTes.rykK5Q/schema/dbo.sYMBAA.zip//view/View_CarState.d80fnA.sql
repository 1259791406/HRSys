CREATE VIEW [dbo].[View_CarState] AS SELECT o.id,CASE WHEN o.o_type = 1 THEN '融租' WHEN o.o_type = 2 THEN '经租' ELSE '未知' END AS type,o.vin,o.oid,o.flowing,o.a_code AS acode,o.Ca_code AS cacode,CASE o.c_name WHEN '' THEN o.c_name ELSE (SELECT name FROM Customer WHERE id = o.c_name) END AS username,CONVERT(VARCHAR(100), o.time, 20) AS ordertime ,CASE i.w_code WHEN '' THEN i.w_code ELSE (SELECT w_name FROM Warehouse WHERE w_code = i.w_code) END AS waName,CONVERT(VARCHAR(100),a.time, 20) AS alltime FROM orderlist o,Inventory i ,AllocationForm a WHERE i.vin = o.vin AND a.vin = o.vin
go

