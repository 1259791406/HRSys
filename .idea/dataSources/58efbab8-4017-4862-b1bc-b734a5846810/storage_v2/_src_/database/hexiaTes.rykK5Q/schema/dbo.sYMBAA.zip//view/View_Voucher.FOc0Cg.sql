CREATE VIEW [dbo].[View_Voucher] AS SELECT id,numbers,code,abstract,num,CASE Sid WHEN '' THEN Sid ELSE (SELECT name FROM subject WHERE code = Sid) END AS sname,cbill,ccheck,cbook,md,mc,CONVERT(VARCHAR(100),time, 20) AS time,istrue,state FROM Voucher
go

