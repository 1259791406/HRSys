CREATE PROCEDURE [dbo].[GetPayPrice]
  @time AS VARCHAR(50) 
AS
BEGIN
	SELECT a.id AS num,b.price FROM UtilYear a LEFT JOIN (SELECT SUM(price) AS price,DATEPART(m,time) AS Ym FROM Receipt WHERE time LIKE '%' + @time + '%' GROUP BY DATEPART(MONTH,time) ) b ON a.id = b.Ym ORDER BY id;
END;
go

