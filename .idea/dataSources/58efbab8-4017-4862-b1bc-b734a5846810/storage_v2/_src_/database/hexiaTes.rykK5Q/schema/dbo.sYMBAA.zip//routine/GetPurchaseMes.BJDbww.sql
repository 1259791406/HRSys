CREATE PROCEDURE [dbo].[GetPurchaseMes]
@id AS VARCHAR(100)
AS
BEGIN
	SELECT v.*,t.name FROM View_TemplateDetails v,Template t  WHERE t.paratCode = v.code AND v.code = (SELECT paratcode FROM Template WHERE id = @id) ORDER BY v.time,v.id ASC;
END;
go

