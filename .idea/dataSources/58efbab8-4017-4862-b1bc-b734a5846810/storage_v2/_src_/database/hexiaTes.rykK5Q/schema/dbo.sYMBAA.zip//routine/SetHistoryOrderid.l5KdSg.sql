CREATE PROCEDURE [dbo].[SetHistoryOrderid]
@orderid AS VARCHAR(50)
AS
BEGIN
 UPDATE Customer SET history_orderid = orderid+'_'+history_orderid,orderid = @orderid WHERE id = (SELECT c_name FROM OrderList WHERE state = 1 AND oid = @orderid);
END
go

exec sp_addextendedproperty 'MS_Description', '此存储过程为修改此用户以前订单', 'SCHEMA', 'dbo', 'PROCEDURE', 'SetHistoryOrderid'
go

