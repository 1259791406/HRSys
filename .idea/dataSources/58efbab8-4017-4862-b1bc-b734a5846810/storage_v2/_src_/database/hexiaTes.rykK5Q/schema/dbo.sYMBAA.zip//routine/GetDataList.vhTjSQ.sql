CREATE PROCEDURE [dbo].[GetDataList]
@Ckyer AS VARCHAR(200),
@pageIndex AS VARCHAR(50),
@pageSize AS VARCHAR(50)
AS
BEGIN
	SELECT b.* FROM (SELECT ROW_NUMBER() OVER(ORDER BY a.id) num,a.* FROM View_CarState  a WHERE 1 = 1 ) b  WHERE b.num  BETWEEN @pageIndex AND @pageSize;
END;
go

