CREATE VIEW [dbo].[View_Receipt] AS SELECT id,orderid,CASE username WHEN '' THEN username ELSE (SELECT name FROM Customer WHERE id = username) END AS username,CONVERT(VARCHAR(100),paytime, 20) AS paytime,price,CASE WHEN paytype = 1 THEN '微信' WHEN paytype = 2 THEN '支付宝' WHEN paytype = 3 THEN '银行卡' WHEN paytype = 4 THEN '线下' ELSE '其他' END AS paytype,num,CONVERT(VARCHAR(100),time, 20) AS time,istrue,state,marke FROM Receipt
go

