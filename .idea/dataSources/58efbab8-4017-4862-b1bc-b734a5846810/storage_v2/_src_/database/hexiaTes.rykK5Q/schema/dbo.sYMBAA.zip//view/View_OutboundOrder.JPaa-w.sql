CREATE VIEW [dbo].[View_OutboundOrder] AS SELECT id,code,CASE username WHEN '' THEN username ELSE (SELECT name FROM Customer WHERE id = username) END AS username,orderid,vin,CONVERT(VARCHAR(100),time, 20) AS time FROM OutboundOrder
go

