CREATE VIEW [dbo].[View_Invoice] AS SELECT id,code,p_code AS pCode,i_number AS iNumber,CASE sid WHEN '' THEN sid ELSE (SELECT name FROM Supplier WHERE sid = i.sid) END AS sid,invoice_Code AS invoiceCode,CASE payer WHEN '' THEN payer ELSE (SELECT name FROM Company WHERE code = i.payer) END AS payer,vin,carnum,color,cartype,yestaxprice,yestax,rate,notaxprice,notax,rateprice,istrue,CONVERT(VARCHAR(100),time, 20) AS time,state FROM Invoice i WHERE state = 1
go

