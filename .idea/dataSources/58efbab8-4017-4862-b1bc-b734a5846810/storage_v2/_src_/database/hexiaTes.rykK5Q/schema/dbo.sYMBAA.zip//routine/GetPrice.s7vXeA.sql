CREATE PROCEDURE [dbo].[GetPrice]
  @time AS VARCHAR(50) 
AS
BEGIN
	SELECT a.id AS num,b.price FROM UtilYear a LEFT JOIN (SELECT ISNULL(CONVERT(DECIMAL(18,2),SUM(MothPrice)),0) AS price,DATEPART(m,time) AS Ym FROM View_Calculation WHERE time LIKE @time + '%' GROUP BY DATEPART(MONTH,time) ) b ON a.id = b.Ym ORDER BY id;
END;
go

