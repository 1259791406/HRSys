CREATE PROCEDURE [dbo].[GetUsernameId]
 @username AS VARCHAR(50)
 AS
BEGIN
	SELECT TOP 1 id FROM Customer WHERE istrue = 1 AND state = 1 AND name = @username ORDER BY time ASC;
END;
go

