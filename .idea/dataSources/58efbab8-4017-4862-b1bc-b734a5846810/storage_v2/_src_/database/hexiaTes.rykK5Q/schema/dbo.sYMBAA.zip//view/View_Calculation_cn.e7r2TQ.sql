CREATE VIEW [dbo].[View_Calculation_cn] AS SELECT code AS 测算表编号,inum AS 序号,orderid AS 客户订单ID,username AS 当前客户人,vin AS 车架号,principal AS 每期租金额,cost AS 摊余成本,m_supply AS 月供, rate AS 实际利率, profit AS 未实现融资收益摊销,CONVERT(VARCHAR(100), m_time, 20) AS 还款日,CASE WHEN istrue = 1 THEN '正常' WHEN istrue = 2 THEN '关闭' ELSE '未知' END AS 订单状态 FROM Calculation WHERE istrue = 1
go

