CREATE VIEW [dbo].[View_Subject] AS SELECT id,code,name,price,CONVERT(VARCHAR(100),time, 20) AS time FROM Subject
go

