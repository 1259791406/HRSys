CREATE VIEW [dbo].[View_CarCost] AS SELECT id,code,vin,gps,SYX_Name,SYX_NoTax,SYX_rate,SYX_YesTax,JQX_Name,JQX_NoTax,JQX_rate,JQX_YesTax,CYX_Name,CYX_NoTax,CYX_rate,CYX_YesTax,ZWX_Name,ZWX_NoTax,ZWX_rate,ZWX_YesTax,XLX_Name,XLX_NoTax,XLX_rate,XLX_YesTax,DKX_Name,DKX_NoTax,DKX_rate,DKX_YesTax,CardFee,PurchaseTax,CONVERT(VARCHAR(100),time, 20) AS time,istrue,marke FROM CarCost
go

