CREATE VIEW [dbo].[View_TemplateDetails] AS SELECT id,code,s_id AS sid,CASE s_id WHEN '' THEN s_id ELSE (SELECT name FROM subject WHERE code = s_id) END AS sname,borrow,loan,falg,CONVERT(VARCHAR(100),time, 20) AS time,istrue,state FROM TemplateDetails
go

