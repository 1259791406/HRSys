CREATE VIEW [dbo].[View_ReturnCar] AS SELECT id,contractNumber,code,orderid,vin,CASE username WHEN '' THEN username ELSE (SELECT name FROM Customer WHERE id = username) END AS username,CONVERT(VARCHAR(100),time, 20) AS time,reason,cacode,istrue,marke FROM ReturnCar
go

