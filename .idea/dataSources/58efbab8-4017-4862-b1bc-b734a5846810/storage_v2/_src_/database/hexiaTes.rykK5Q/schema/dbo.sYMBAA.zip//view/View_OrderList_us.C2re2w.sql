CREATE VIEW [dbo].[View_OrderList_us] AS SELECT id,vin,CASE WHEN O_type = 1 THEN '融租' WHEN O_type = 2 THEN '经租' ELSE '未知' END AS type,contractNumber,contractNumberPrice,a_code AS ccode,Ca_code AS cacode,C_Name AS cname,Oid AS orderid,Flowing,CONVERT(VARCHAR(100), time, 20) AS time,FirstPrice,LastPrice,MothNum,MothPrice,CarPrice,istrue,ServicePrice,marke  FROM OrderList
go

