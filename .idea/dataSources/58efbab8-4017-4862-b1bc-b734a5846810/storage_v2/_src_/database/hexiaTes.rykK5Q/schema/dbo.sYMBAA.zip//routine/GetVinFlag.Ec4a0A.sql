CREATE PROCEDURE [dbo].[GetVinFlag]
 @vin AS VARCHAR(50)
AS
BEGIN
 SELECT COUNT(code) FROM Inventory WHERE istrue = 2 AND falg = 2 AND inum = 2 AND state = 1 AND vin = @vin;
END;
go

