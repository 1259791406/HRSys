CREATE PROCEDURE [dbo].[SetOrderid]
@orderid AS VARCHAR(50)
AS
BEGIN
	UPDATE Customer SET orderid = @orderid WHERE id = (SELECT c_name FROM OrderList WHERE state = 1 AND oid = @orderid);
END
go

exec sp_addextendedproperty 'MS_Description', '此存储过程为添加导入客户档案时', 'SCHEMA', 'dbo', 'PROCEDURE', 'SetOrderid'
go

