CREATE VIEW [dbo].[View_GL_VoucherRecord_Detailed] AS SELECT id,JiePrice, DaiPrice, type, inum, num, JieSubjectCode, JieName, DaiSubjectCode, DaiName, keys, code, YearMouthDay, CONVERT(VARCHAR(100),SysTime, 20) AS SysTime, CONVERT(VARCHAR(100),time, 20) AS time, state FROM GL_VoucherRecord_Detailed
go

