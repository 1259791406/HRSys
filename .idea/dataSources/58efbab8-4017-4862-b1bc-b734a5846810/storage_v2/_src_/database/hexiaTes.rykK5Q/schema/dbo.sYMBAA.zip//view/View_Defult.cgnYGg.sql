CREATE VIEW [dbo].[View_Defult] AS SELECT id,orderid,price,CONVERT(VARCHAR(100),time, 20) AS time,state,marke FROM defultPrice
go

