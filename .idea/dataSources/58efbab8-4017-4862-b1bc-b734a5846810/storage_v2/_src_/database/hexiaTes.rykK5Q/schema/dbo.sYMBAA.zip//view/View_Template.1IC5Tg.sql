CREATE VIEW [dbo].[View_Template] AS SELECT id,code,name,paratCode,CONVERT(VARCHAR(100),time, 20) AS time,istrue,state FROM Template
go

