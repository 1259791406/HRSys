CREATE VIEW [dbo].[View_Supplier] AS SELECT sid,name,username,phone,email,address,CONVERT(VARCHAR(100), time, 20) AS time,marke FROM Supplier
go

