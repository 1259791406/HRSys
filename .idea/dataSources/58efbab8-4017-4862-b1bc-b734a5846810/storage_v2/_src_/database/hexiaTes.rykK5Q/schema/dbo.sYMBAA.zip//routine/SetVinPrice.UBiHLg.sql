CREATE PROCEDURE [dbo].[SetVinPrice]
  @vin AS VARCHAR(50) 
AS
BEGIN
	INSERT INTO CarCost (code,vin,gps,NoTax,rate,YesTax,SYX_Name,SYX_NoTax,SYX_rate,SYX_YesTax,JQX_Name,JQX_NoTax,JQX_rate,JQX_YesTax,CYX_Name,CYX_NoTax,CYX_rate,CYX_YesTax,ZWX_Name,ZWX_NoTax,ZWX_rate,ZWX_YesTax,XLX_Name,XLX_NoTax,XLX_rate,XLX_YesTax,DKX_Name,DKX_NoTax,DKX_rate,DKX_YesTax,CardFee,PurchaseTax,istrue) SELECT NEWID(),vin,gps,NoTax,rate,YesTax,SYX_Name,SYX_NoTax,SYX_rate,SYX_YesTax,JQX_Name,JQX_NoTax,JQX_rate,JQX_YesTax,CYX_Name,CYX_NoTax,CYX_rate,CYX_YesTax,ZWX_Name,ZWX_NoTax,ZWX_rate,ZWX_YesTax,XLX_Name,XLX_NoTax,XLX_rate,XLX_YesTax,DKX_Name,DKX_NoTax,DKX_rate,DKX_YesTax,CardFee,PurchaseTax,1 AS istrue FROM Inventory WHERE vin = @vin;
		UPDATE Inventory SET falg = 2 WHERE state = 1 AND vin = @vin;
END;
go

