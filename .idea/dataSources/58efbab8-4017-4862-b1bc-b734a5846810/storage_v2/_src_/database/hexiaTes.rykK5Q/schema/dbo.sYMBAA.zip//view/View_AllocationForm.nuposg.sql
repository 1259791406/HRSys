CREATE VIEW [dbo].[View_AllocationForm] AS SELECT id,orderid,CASE oldcode WHEN '' THEN oldcode ELSE (SELECT w_name FROM Warehouse WHERE w_code = oldcode) END AS oldName,CASE newCode WHEN '' THEN newCode ELSE (SELECT w_name FROM Warehouse WHERE w_code = newCode) END AS newName,vin,CONVERT(VARCHAR(100), time, 20) AS time FROM AllocationForm
go

