CREATE VIEW [dbo].[View_TiaoXiu] AS SELECT id,userid,CASE userid WHEN '' THEN '' ELSE (SELECT username FROM hnuser WHERE userid = t.userid) END AS username,code,CONVERT(VARCHAR(20),startTime,20) AS startTime,ISNULL(size,0) AS size,make,state,CONVERT(VARCHAR(20),AddTime,20) AS AddTime FROM tiaoXiu t
go

