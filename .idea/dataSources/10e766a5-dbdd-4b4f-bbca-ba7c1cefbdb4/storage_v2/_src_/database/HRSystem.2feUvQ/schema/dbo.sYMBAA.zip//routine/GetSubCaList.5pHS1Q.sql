CREATE PROCEDURE [dbo].[GetSubCaList]
@userid AS VARCHAR(50)
AS
BEGIN
-- 	7：天数		8：小时
	SELECT start+'_'+CONVERT(VARCHAR,id)id FROM View_CalendarList WHERE start > GETDATE() AND start < DATEADD(day, 7, DATEADD(hh, 8, GETDATE())) AND day IN (SELECT userid FROM hnuser WHERE deptid = (SELECT deptid FROM hnuser WHERE userid = @userid))
END
go

