CREATE VIEW [dbo].[View_over_cn] AS SELECT id,code,userid,ISNULL(startTime, '') AS startTime,ISNULL(endTime, '') AS endTime,CASE type WHEN '' THEN type ELSE (SELECT name FROM OverType WHERE id = type) END type,CONVERT(VARCHAR(100), ApplyTime, 20) AS ApplyTime,
CASE state
	WHEN '' THEN ''
	WHEN '1' THEN '正在审批'
	WHEN '2' THEN '同意'
	WHEN '3' THEN '拒绝'
	ELSE '未知'
END AS state,ISNULL(marke, '') AS marke,Approval FROM Overtime o
go

