CREATE PROCEDURE [dbo].[RefuseOver]
@code AS VARCHAR(50),
@orderNum AS VARCHAR(50)
AS
BEGIN
	UPDATE TaskList SET flag = 3 WHERE code = @code;
	UPDATE TaskList SET state = 3 WHERE code = @code AND orderNum = @orderNum;
END
go

