CREATE VIEW [dbo].[View_leave] AS SELECT id,code,CASE userid WHEN '' THEN '' ELSE (SELECT username FROM hnuser WHERE userid = l.userid) END userid,Duration,time,CONVERT(VARCHAR(20),addTime,20) AS addTime,CASE state WHEN 1 THEN '正在审批' WHEN 2 THEN '同意' WHEN 3 THEN '拒绝' ELSE '异常' END state,ISNULL(marke, '') AS marke,CASE str1 WHEN '' THEN '' ELSE (SELECT name FROM leaveType WHERE id = str1) END str1,str2,str3,str4,str5,str6,str7,str8,str9,str10,Approval FROM leave l
go

