CREATE VIEW View_Role AS 
SELECT id,name,sign,state,CONVERT(VARCHAR(100), time, 20) AS time,makre FROM Role WHERE state = 1
go

