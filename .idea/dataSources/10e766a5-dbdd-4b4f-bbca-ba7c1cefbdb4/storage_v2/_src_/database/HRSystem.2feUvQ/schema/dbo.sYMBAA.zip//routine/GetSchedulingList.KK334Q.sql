CREATE PROCEDURE [dbo].[GetSchedulingList]
@time AS VARCHAR(50)
AS
BEGIN
	SELECT CASE ca.userId WHEN '' THEN userId ELSE (SELECT username FROM hnuser WHERE userid = ca.userId) END AS title,CONVERT(VARCHAR(100),ca.start, 20) +' - '+CONVERT(VARCHAR(100),ca.endTime, 20) AS name,'' AS ratio,state AS status,CASE state WHEN '' THEN state ELSE (SELECT name FROM stateList WHERE code = ca.state) END AS statusText FROM calendarList ca 
	
	WHERE REPLACE(CONVERT(varchar(10),ca.start,120),N'-0','-') = @time
-- 	WHERE DATEPART(month, ca.time) = DATEPART(month, @time) AND DATEPART(YEAR, ca.time) = DATEPART(YEAR, @time)
END
go

