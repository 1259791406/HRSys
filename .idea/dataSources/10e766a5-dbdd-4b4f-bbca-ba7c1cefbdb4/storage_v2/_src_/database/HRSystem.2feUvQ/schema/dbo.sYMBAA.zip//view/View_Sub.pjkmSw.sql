CREATE VIEW [dbo].[View_Sub] AS SELECT id, code, table_id AS tableId,CASE startUserid WHEN '' THEN '' ELSE (SELECT username FROM hnuser WHERE userid = startUserid) END startUserid,CASE endUserid WHEN '' THEN '' ELSE (SELECT username FROM hnuser WHERE userid = endUserid) END endUserid, state, CONVERT(VARCHAR(100),time, 20) AS time, str1, str2, str3, str4, str5, str6, str7, str8, str9, str10, str11, str12, str13, str14, str15, str16, str17, str18, str19, str20, marke FROM Substitute;
go

