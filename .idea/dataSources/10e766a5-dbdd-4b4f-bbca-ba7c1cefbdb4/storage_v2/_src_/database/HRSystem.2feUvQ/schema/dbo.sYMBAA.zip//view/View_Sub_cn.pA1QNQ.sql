CREATE VIEW View_Sub_cn AS
SELECT id, code, table_id,startUserid, endUserid, state, CONVERT(VARCHAR(100),time, 20) AS time, str1, str2, str3, str4, str5, str6, str7, str8, str9, str10, str11, str12, str13, str14, str15, str16, str17, str18, str19, str20, marke FROM Substitute
go

