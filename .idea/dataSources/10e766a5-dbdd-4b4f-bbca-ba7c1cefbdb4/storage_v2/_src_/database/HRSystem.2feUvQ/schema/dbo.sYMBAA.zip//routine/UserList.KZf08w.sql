CREATE PROCEDURE [dbo].[UserList]
@page AS VARCHAR(50),
@limit AS VARCHAR(50),
@data AS VARCHAR(MAX)
AS
BEGIN
-- 创建以下临时变量
DECLARE @pageSize AS INT
DECLARE @mes AS VARCHAR(MAX)

IF (@page = '1') BEGIN
	SET @page = '1'
	SET @limit = CONVERT(INT,@page) * CONVERT(INT,@limit)
END ELSE BEGIN
	SET @pageSize = CONVERT(INT,@limit) * CONVERT(INT,@page)
	SET @page = (CONVERT(INT,@limit) * (CONVERT(INT,@page) - 1 ) + 1 )
	SET @limit = @pageSize
END
SET @mes = 'SELECT b.* FROM (SELECT ROW_NUMBER() OVER(ORDER BY a.id) s,a.* FROM View_user a WHERE 1 = 1 ' + @data + ' ) b  WHERE b.s BETWEEN ' + @page + ' AND ' + @limit ;
EXEC  (@mes)	 
END
go

