CREATE PROCEDURE [dbo].[GetTaskList]
@userid AS VARCHAR(50),
@code AS VARCHAR(50)
AS
BEGIN
	SELECT * FROM Task WHERE code = (SELECT task_code FROM BillTask WHERE table_id =	(SELECT table_id FROM Overtime WHERE code = @code AND userid = @userid ) AND depe_id = (SELECT deptid FROM hnuser WHERE userId = @userid )) ORDER BY id ASC;
END
go

