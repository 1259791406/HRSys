CREATE PROCEDURE [dbo].[GetDateList]
@time AS VARCHAR(20)
AS
BEGIN

	SELECT REPLACE(CONVERT(varchar(10),ca.start,120),N'-0','-') FROM calendarList ca WHERE DATEDIFF(MONTH,start,@time) = 0 GROUP BY REPLACE(CONVERT(varchar(10),ca.start,120),N'-0','-')
END
go

