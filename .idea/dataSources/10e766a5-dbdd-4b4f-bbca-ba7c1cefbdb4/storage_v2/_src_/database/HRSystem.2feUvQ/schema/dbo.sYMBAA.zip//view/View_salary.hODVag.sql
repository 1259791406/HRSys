CREATE VIEW [dbo].[View_salary] AS SELECT
	id,
	ISNULL(CONVERT( DECIMAL ( 18, 2 ), basic ),0) AS basic,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.hour ),0) AS HOUR,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.night ),0) AS night,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), month_performance ),0) AS monthperformance,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), quarter_performance ),0) AS quarter_performance,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), year_end_bonus ),0) AS yearendbonus,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), overtime ),0) AS overtime,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), allowance ),0) AS allowance,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), particularly_aawards ),0) AS particularlyaawards,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.festival ),0) AS festiv,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.travel ),0) AS travel,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), provide_for_the_aged ),0) AS providefortheaged,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), medical_treatment ),0) AS medicaltreatment,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), housing ),0) AS housing,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), in_dry_dock ),0) AS indrydock,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), occupational_injury ),0) AS occupationalinjury,
	

	
	
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.Pension_Company ),0) AS PensionCompany,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.Medcal_Company ),0) AS MedcalCompany,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.Unemployment_Company ),0) AS UnemploymentCompany,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.Birth_Company ),0) AS BirthCompany,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.Industriak_Company ),0) AS IndustriakCompany,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.Housing_Company ),0) AS HousingCompany,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.Children ),0) AS Children,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.SupportTheOld),0) AS SupportTheOld,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.Adult ),0) AS Adult,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.Draw ),0) AS Draw,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.Renting ),0) AS Renting,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.Serious ),0) AS Serious,
	
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.late ),0) AS late,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.leave ),0) AS leave,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.early ),0) AS early,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), Overtime_pay ),0) AS Overtime_pay,
		CONVERT ( DECIMAL ( 18, 2 ), absenteeism+basic+overtime+night+allowance+month_performance+quarter_performance+year_end_bonus+particularly_aawards+festival+travel-provide_for_the_aged-medical_treatment-housing-in_dry_dock-occupational_injury-leave-late-early-absenteeism-Overtime_pay-eat)	 AS salary,
	CONVERT(VARCHAR(20) ,time ,20) AS TIME,
	userid,
	state,
	code,
	items,
CASE
	userid 
	WHEN '' THEN
	'' ELSE ( SELECT username FROM hnuser WHERE userid = s.userid ) 
	END AS username,
	ISNULL(CONVERT ( DECIMAL ( 18, 2 ), s.eat ),0) AS eat
FROM
	salary s
go

