CREATE view View_reim AS
SELECT id,code,userid,CASE r.userid
	WHEN '' THEN ''
	ELSE (SELECT username FROM hnuser WHERE userid = r.userid)
END AS username,CASE type
	WHEN '' THEN ''
	ELSE (SELECT name FROM ReimType WHERE code = type)
END AS type,CONVERT(DECIMAL(18,2), price) AS price,CONVERT(VARCHAR(20),time,20) AS time,App FROM Reimbursement r
go

