CREATE VIEW [dbo].[View_over] AS SELECT id,code,CASE o.userid WHEN '' THEN o.userid ELSE (SELECT username FROM hnuser WHERE userId = o.userid) END userid,ISNULL(startTime, '') AS startTime,ISNULL(endTime, '') AS endTime,CASE type WHEN '' THEN type ELSE (SELECT name FROM OverType WHERE id = type) END type,CONVERT(VARCHAR(100), ApplyTime, 20) AS ApplyTime,state,ISNULL(marke, '') AS marke,Approval FROM Overtime o
go

