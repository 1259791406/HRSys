CREATE VIEW [dbo].[View_user] AS SELECT
	id,
	userid,
	username,
	password,
	sex,
	phone,
	weixinNum,
	CONVERT ( VARCHAR ( 100 ), DAY, 23 ) AS DAY,
CASE
	deptid 
	WHEN '' THEN
	deptid ELSE ( SELECT name FROM hn_dept WHERE id = deptid ) 
	END deptid,
	idcard,
	fileid,
	CONVERT ( VARCHAR ( 100 ), TIME, 20 ) AS TIME,
	CONVERT ( VARCHAR ( 100 ), logintime, 20 ) AS logintime,
	num,
	state,
	role_id AS roleId,
	CONVERT ( DECIMAL ( 18, 2 ), salary ) AS salary,
	NativePlace,
CASE
	Education 
	WHEN '' THEN
	Education ELSE ( SELECT name FROM Education WHERE id = Education ) 
	END Education,
	DATEDIFF(
	YEAR,
	DAY,
	GETDATE()) + 1 AS age,
	SIZE,
	ISNULL( Children, 0 ) AS Children,
	ISNULL( SupportTheOld, 0 ) AS SupportTheOld,
	ISNULL( Adult, 0 ) AS Adult,
	ISNULL( Serious, 0 ) AS Serious,
	ISNULL( Renting, 0 ) AS Renting,
	ISNULL( Draw, 0 ) AS Draw,
	allowance,Reserve13,CASE UserState
	WHEN '1' THEN '在职'
	WHEN '2' THEN '离职'
	ELSE '未知'
END
UserState,post,SalaryCardNo,ThreadLength,
	CASE UserType WHEN '1' THEN 'DL' WHEN '2' THEN 'IDL' WHEN '3' THEN '管理人员' ELSE '未知' END UserType,
	passport,
	CONVERT ( VARCHAR ( 19 ), EntryTime, 20 ) AS EntryTime,
	CONVERT ( VARCHAR ( 19 ), ContractExpirationDate, 20 ) AS ContractExpirationDate,
	height,weight,email,
	CASE marriage
	WHEN '1' THEN '已婚'
	WHEN '2' THEN '未婚'
END
marriage,urgent_name AS urgentname,urgent_relationship AS urgentrelationship,urgent_phone AS urgentphone,birthplace,address,marke 
FROM
	hnuser;
go

