CREATE VIEW View_jur AS 
SELECT id, name, url, icon, paratid, state, CONVERT(VARCHAR(100), time, 20) AS tine, marke FROM Jurisdiction WHERE state = 1
go

